/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      colors: {
        theme: {
          dark: '#0B0C10',    // Dark background
          gray: '#1F2833',    // Secondary background
          light: '#C5C6C7',   // Light text
          accent: '#66FCF1',  // Primary accent
          secondary: '#45A29E' // Secondary accent
        }
      }
    },
  },
  plugins: [],
}