import { Navbar } from './components/Layout/Navbar';
import { Hero } from './components/Hero/Hero';
import { About } from './components/About/About';
import { Skills } from './components/Skills/Skills';
import { Experience } from './components/Experience/Experience';
import { Education } from './components/Education/Education';
import { Projects } from './components/Projects/Projects';
import { Services } from './components/Services/Services';
import { Testimonials } from './components/Testimonials/Testimonials';
import { Blog } from './components/Blog/Blog';
import { Awards } from './components/Awards/Awards';
import { Publications } from './components/Publications/Publications';
import { Speaking } from './components/Speaking/Speaking';
import { Research } from './components/Research/Research';
import { Volunteering } from './components/Volunteering/Volunteering';
import { Certifications } from './components/Certifications/Certifications';
import { Tools } from './components/Tools/Tools';
import { Process } from './components/Process/Process';
import { Contact } from './components/Contact/Contact';
import { Footer } from './components/Layout/Footer';
import { Cursor } from './components/Cursor/Cursor';

function App() {
  return (
    <div className="min-h-screen bg-theme-dark">
      <Cursor />
      <Navbar />
      <Hero />
      <About />
      <Skills />
      <Experience />
      <Education />
      <Projects />
      <Services />
      <Testimonials />
      <Blog />
      <Awards />
      <Publications />
      <Speaking />
      <Research />
      <Volunteering />
      <Certifications />
      <Tools />
      <Process />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;