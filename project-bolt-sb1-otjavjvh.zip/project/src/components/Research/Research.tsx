import { motion } from 'framer-motion';

const researchProjects = [
  {
    title: "AI-Powered Development Tools",
    status: "Ongoing",
    field: "Artificial Intelligence",
    description: "Research on integrating AI capabilities into development workflows for improved productivity.",
    highlights: [
      "Machine learning models for code suggestions",
      "Automated code review systems",
      "Intelligent debugging tools"
    ]
  },
  {
    title: "Next-Generation Web Frameworks",
    status: "Completed",
    field: "Web Development",
    description: "Analysis and development of innovative web framework architectures.",
    highlights: [
      "Performance optimization techniques",
      "Novel state management approaches",
      "Enhanced developer experience"
    ]
  },
  {
    title: "Quantum Computing Applications",
    status: "Planning",
    field: "Quantum Computing",
    description: "Exploring potential applications of quantum computing in web technologies.",
    highlights: [
      "Quantum algorithms for web security",
      "Quantum-resistant cryptography",
      "Hybrid classical-quantum systems"
    ]
  }
];

export const Research = () => {
  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <h2 className="text-4xl font-bold text-center text-white mb-16">Research Projects</h2>
          
          <div className="space-y-8">
            {researchProjects.map((project, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-gray-700 rounded-xl p-8"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">{project.title}</h3>
                    <p className="text-blue-400">{project.field}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                    project.status === 'Ongoing' ? 'bg-green-500 text-white' :
                    project.status === 'Completed' ? 'bg-blue-500 text-white' :
                    'bg-yellow-500 text-gray-900'
                  }`}>
                    {project.status}
                  </span>
                </div>
                <p className="text-gray-300 mb-4">{project.description}</p>
                <ul className="space-y-2">
                  {project.highlights.map((highlight, i) => (
                    <li key={i} className="flex items-center text-gray-400">
                      <span className="w-2 h-2 bg-blue-500 rounded-full mr-3" />
                      {highlight}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};