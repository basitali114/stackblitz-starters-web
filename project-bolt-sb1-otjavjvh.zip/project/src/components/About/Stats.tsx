import { motion } from 'framer-motion';

const stats = [
  { label: 'Projects Completed', value: '50+' },
  { label: 'Happy Clients', value: '30+' },
  { label: 'Years Experience', value: '5+' },
  { label: 'Awards Won', value: '10+' },
];

export const Stats = () => {
  return (
    <div className="grid grid-cols-2 gap-6">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: index * 0.1 }}
          className="bg-theme-dark p-6 rounded-lg text-center"
        >
          <h4 className="text-3xl font-bold text-theme-accent mb-2">{stat.value}</h4>
          <p className="text-theme-light">{stat.label}</p>
        </motion.div>
      ))}
    </div>
  );
};