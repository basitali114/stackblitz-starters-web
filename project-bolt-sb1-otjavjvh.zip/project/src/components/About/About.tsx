import { motion } from 'framer-motion';
import { Stats } from './Stats';

export const About = () => {
  return (
    <section id="about" className="py-20 bg-theme-gray">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <h2 className="text-4xl font-bold text-center mb-12 text-theme-accent">About Me</h2>
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold mb-4 text-theme-light">My Journey</h3>
              <p className="text-theme-light/80 leading-relaxed mb-6">
                With over 5 years of experience in web development, I've helped numerous clients 
                transform their ideas into reality. My passion lies in creating intuitive, 
                performant applications that solve real-world problems.
              </p>
              <p className="text-theme-light/80 leading-relaxed">
                I specialize in modern web technologies and stay up-to-date with the latest 
                industry trends to deliver cutting-edge solutions.
              </p>
            </div>
            <Stats />
          </div>
        </motion.div>
      </div>
    </section>
  );
};