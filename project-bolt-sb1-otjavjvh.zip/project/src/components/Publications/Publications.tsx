import { motion } from 'framer-motion';

const publications = [
  {
    title: "Modern Web Development Practices",
    journal: "Tech Journal International",
    year: "2023",
    description: "A comprehensive study on modern web development practices and their impact on application performance.",
    link: "#"
  },
  {
    title: "AI Integration in Web Applications",
    journal: "Digital Innovation Review",
    year: "2022",
    description: "Research paper on effective integration of AI capabilities in web applications.",
    link: "#"
  },
  {
    title: "Performance Optimization Techniques",
    journal: "Web Technology Quarterly",
    year: "2022",
    description: "Analysis of advanced performance optimization techniques for modern web applications.",
    link: "#"
  }
];

export const Publications = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <h2 className="text-4xl font-bold text-center mb-16">Publications</h2>
          
          <div className="space-y-8">
            {publications.map((pub, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-gray-50 rounded-xl p-6"
              >
                <h3 className="text-xl font-bold mb-2">{pub.title}</h3>
                <div className="text-blue-500 mb-3">
                  {pub.journal} • {pub.year}
                </div>
                <p className="text-gray-600 mb-4">{pub.description}</p>
                <a
                  href={pub.link}
                  className="text-blue-500 hover:text-blue-600 font-semibold"
                >
                  Read Publication →
                </a>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};