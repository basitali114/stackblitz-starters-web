import { motion } from 'framer-motion';

const certifications = [
  {
    name: "AWS Solutions Architect Professional",
    organization: "Amazon Web Services",
    date: "2023",
    description: "Advanced certification for designing distributed systems on AWS.",
    badge: "https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?auto=format&fit=crop&q=80&w=100"
  },
  {
    name: "Google Cloud Professional Architect",
    organization: "Google Cloud",
    date: "2023",
    description: "Expert-level certification for Google Cloud architecture.",
    badge: "https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?auto=format&fit=crop&q=80&w=100"
  },
  {
    name: "Microsoft Azure Solutions Expert",
    organization: "Microsoft",
    date: "2022",
    description: "Expert certification for Azure cloud solutions.",
    badge: "https://images.unsplash.com/photo-1523474253046-8cd2748b5fd2?auto=format&fit=crop&q=80&w=100"
  }
];

export const Certifications = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <h2 className="text-4xl font-bold text-center mb-16">Certifications</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {certifications.map((cert, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white rounded-xl p-6 shadow-lg"
              >
                <div className="flex items-center mb-4">
                  <img
                    src={cert.badge}
                    alt={cert.name}
                    className="w-12 h-12 rounded-full mr-4"
                  />
                  <div>
                    <h3 className="text-lg font-bold">{cert.name}</h3>
                    <p className="text-blue-500">{cert.organization}</p>
                  </div>
                </div>
                <p className="text-gray-600 mb-2">{cert.description}</p>
                <p className="text-gray-500">Issued: {cert.date}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};