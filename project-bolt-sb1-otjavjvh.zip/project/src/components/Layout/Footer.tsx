import { motion } from 'framer-motion';

export const Footer = () => {
  return (
    <footer className="bg-theme-dark text-theme-light/60 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <img 
              src="https://i.ibb.co/VxKN3Rj/wmb.png" 
              alt="WMB Logo" 
              className="h-10 w-auto brightness-200 mb-4"
            />
            <p className="mb-4">Crafting digital experiences that leave lasting impressions.</p>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-theme-accent transition-colors">Twitter</a>
              <a href="#" className="hover:text-theme-accent transition-colors">LinkedIn</a>
              <a href="#" className="hover:text-theme-accent transition-colors">GitHub</a>
            </div>
          </div>
          <div>
            <h4 className="text-theme-light text-lg font-semibold mb-4">Services</h4>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-theme-accent transition-colors">Web Development</a></li>
              <li><a href="#" className="hover:text-theme-accent transition-colors">Mobile Development</a></li>
              <li><a href="#" className="hover:text-theme-accent transition-colors">Cloud Solutions</a></li>
              <li><a href="#" className="hover:text-theme-accent transition-colors">AI & ML</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-theme-light text-lg font-semibold mb-4">Company</h4>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-theme-accent transition-colors">About</a></li>
              <li><a href="#" className="hover:text-theme-accent transition-colors">Projects</a></li>
              <li><a href="#" className="hover:text-theme-accent transition-colors">Blog</a></li>
              <li><a href="#" className="hover:text-theme-accent transition-colors">Contact</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-theme-light text-lg font-semibold mb-4">Contact</h4>
            <ul className="space-y-2">
              <li>contact@example.com</li>
              <li>+1 (555) 123-4567</li>
              <li>San Francisco, CA</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-theme-gray/20 mt-12 pt-8 text-center">
          <p>&copy; {new Date().getFullYear()} All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};