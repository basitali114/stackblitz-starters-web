import { motion } from 'framer-motion';

const speakingEngagements = [
  {
    title: "Future of Web Development",
    event: "TechConf 2023",
    date: "December 2023",
    location: "San Francisco, CA",
    description: "Keynote speech on emerging trends and technologies in web development."
  },
  {
    title: "Building Scalable Applications",
    event: "DevSummit 2023",
    date: "October 2023",
    location: "New York, NY",
    description: "Technical workshop on architecture patterns for scalable applications."
  },
  {
    title: "AI in Modern Applications",
    event: "AI Tech Week",
    date: "September 2023",
    location: "London, UK",
    description: "Panel discussion on integrating AI capabilities in modern applications."
  }
];

export const Speaking = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <h2 className="text-4xl font-bold text-center mb-16">Speaking Engagements</h2>
          
          <div className="space-y-8">
            {speakingEngagements.map((engagement, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white rounded-xl p-8 shadow-lg"
              >
                <div className="flex flex-wrap justify-between items-start mb-4">
                  <div>
                    <h3 className="text-2xl font-bold mb-2">{engagement.title}</h3>
                    <p className="text-blue-500 font-semibold">{engagement.event}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-gray-600">{engagement.date}</p>
                    <p className="text-gray-500">{engagement.location}</p>
                  </div>
                </div>
                <p className="text-gray-600">{engagement.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};