import { motion } from 'framer-motion';
import { ShootingStars } from '../Background/ShootingStars';

export const Hero = () => {
  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-theme-dark">
      <ShootingStars />
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center text-theme-light"
        >
          <h1 className="text-6xl md:text-8xl font-bold mb-6">
            Creative
            <span className="text-theme-accent"> Developer</span>
          </h1>
          <p className="text-xl md:text-2xl text-theme-light mb-12 max-w-2xl mx-auto">
            Crafting digital experiences that leave lasting impressions
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-theme-accent text-theme-dark px-8 py-4 rounded-full text-lg font-semibold hover:bg-theme-secondary transition-colors"
          >
            View Projects
          </motion.button>
        </motion.div>
      </div>
    </div>
  );
};