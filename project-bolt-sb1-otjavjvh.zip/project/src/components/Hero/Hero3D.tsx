import { Canvas } from '@react-three/fiber';
import { OrbitControls, Sphere } from '@react-three/drei';
import { useSpring, animated } from '@react-spring/three';

const AnimatedSphere = () => {
  const springs = useSpring({
    from: { scale: [0, 0, 0] },
    to: { scale: [1, 1, 1] },
    config: { mass: 2, tension: 170, friction: 12 }
  });

  return (
    <animated.mesh scale={springs.scale}>
      <Sphere args={[1, 32, 32]}>
        <meshStandardMaterial
          color="#4338ca"
          roughness={0.1}
          metalness={0.8}
        />
      </Sphere>
    </animated.mesh>
  );
};

export const Hero3D = () => {
  return (
    <Canvas className="h-[500px]">
      <OrbitControls enableZoom={false} />
      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 10, 5]} intensity={1} />
      <AnimatedSphere />
    </Canvas>
  );
};