import { motion } from 'framer-motion';

const processSteps = [
  {
    number: "01",
    title: "Discovery",
    description: "Understanding your requirements, goals, and vision through detailed consultation.",
    details: [
      "Initial Consultation",
      "Requirements Gathering",
      "Project Scope Definition",
      "Timeline Planning",
      "Budget Estimation"
    ]
  },
  {
    number: "02",
    title: "Planning",
    description: "Creating comprehensive project plans and selecting the right technologies.",
    details: [
      "Technical Architecture",
      "Technology Stack Selection",
      "Resource Allocation",
      "Risk Assessment",
      "Milestone Definition"
    ]
  },
  {
    number: "03",
    title: "Development",
    description: "Building your solution using agile methodologies and best practices.",
    details: [
      "Iterative Development",
      "Regular Updates",
      "Code Reviews",
      "Quality Assurance",
      "Performance Optimization"
    ]
  },
  {
    number: "04",
    title: "Delivery",
    description: "Deploying your solution and ensuring smooth operation.",
    details: [
      "Testing & QA",
      "Deployment",
      "Documentation",
      "Training",
      "Support & Maintenance"
    ]
  }
];

export const Process = () => {
  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-6xl mx-auto"
        >
          <h2 className="text-4xl font-bold text-center text-white mb-16">Development Process</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step, index) => (
              <motion.div
                key={step.number}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="relative"
              >
                {/* Number */}
                <div className="absolute -top-8 -left-4 text-6xl font-bold text-blue-500/20">
                  {step.number}
                </div>
                
                {/* Content */}
                <div className="bg-gray-700 rounded-xl p-6 pt-8">
                  <h3 className="text-2xl font-bold text-white mb-4">{step.title}</h3>
                  <p className="text-gray-300 mb-6">{step.description}</p>
                  <ul className="space-y-3">
                    {step.details.map((detail, i) => (
                      <li key={i} className="flex items-center text-gray-400">
                        <span className="w-2 h-2 bg-blue-500 rounded-full mr-3" />
                        {detail}
                      </li>
                    ))}
                  </ul>
                </div>
                
                {/* Connector line for all except last item */}
                {index < processSteps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 w-8 h-0.5 bg-blue-500" />
                )}
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};