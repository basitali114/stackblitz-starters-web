import { ProjectCard } from './ProjectCard';

const projects = [
  {
    title: "E-Commerce Platform",
    description: "A modern e-commerce solution with real-time inventory and AI-powered recommendations.",
    image: "https://images.unsplash.com/photo-1661956602116-aa6865609028?auto=format&fit=crop&q=80&w=800"
  },
  {
    title: "Financial Dashboard",
    description: "Interactive dashboard with real-time data visualization and predictive analytics.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=800"
  },
  {
    title: "Social Media App",
    description: "Next-gen social platform with AR filters and real-time collaboration features.",
    image: "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&q=80&w=800"
  }
];

export const Projects = () => {
  return (
    <section className="py-20 bg-theme-gray">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12 text-theme-accent">Featured Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={index} {...project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};