import { motion } from 'framer-motion';

const awards = [
  {
    title: "Best Web Development Agency",
    organization: "Tech Excellence Awards",
    year: "2023",
    description: "Recognized for outstanding achievements in web development and innovation."
  },
  {
    title: "Innovation in Technology",
    organization: "Digital Impact Awards",
    year: "2022",
    description: "Awarded for groundbreaking solutions in digital transformation."
  },
  {
    title: "Developer of the Year",
    organization: "Code Masters Summit",
    year: "2022",
    description: "Acknowledged for exceptional contributions to the development community."
  },
  {
    title: "Best Mobile Application",
    organization: "App Development Awards",
    year: "2021",
    description: "Awarded for creating an innovative mobile solution with outstanding user experience."
  }
];

export const Awards = () => {
  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-6xl mx-auto"
        >
          <h2 className="text-4xl font-bold text-center text-white mb-16">Awards & Recognition</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {awards.map((award, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-gray-700 rounded-xl p-8"
              >
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mr-4">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6 text-white"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"
                      />
                    </svg>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">{award.title}</h3>
                    <p className="text-blue-400">{award.organization}</p>
                  </div>
                </div>
                <div className="ml-16">
                  <p className="text-gray-300 mb-2">{award.description}</p>
                  <p className="text-gray-400">Year: {award.year}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};