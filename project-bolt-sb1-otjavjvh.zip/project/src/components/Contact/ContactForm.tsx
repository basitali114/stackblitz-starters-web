import { motion } from 'framer-motion';
import { useState, FormEvent } from 'react';

export const ContactForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <motion.input
          whileFocus={{ scale: 1.02 }}
          type="text"
          placeholder="Name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          required
          className="w-full px-4 py-3 bg-theme-gray rounded-lg focus:outline-none focus:ring-2 focus:ring-theme-accent text-theme-light"
        />
        <motion.input
          whileFocus={{ scale: 1.02 }}
          type="email"
          placeholder="Email"
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          required
          className="w-full px-4 py-3 bg-theme-gray rounded-lg focus:outline-none focus:ring-2 focus:ring-theme-accent text-theme-light"
        />
      </div>
      <motion.textarea
        whileFocus={{ scale: 1.02 }}
        placeholder="Your message"
        value={formData.message}
        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
        required
        rows={6}
        className="w-full px-4 py-3 bg-theme-gray rounded-lg focus:outline-none focus:ring-2 focus:ring-theme-accent text-theme-light"
      />
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        type="submit"
        className="bg-theme-accent text-theme-dark px-8 py-3 rounded-full text-lg font-semibold hover:bg-theme-secondary transition-colors"
      >
        Send Message
      </motion.button>
    </form>
  );
};