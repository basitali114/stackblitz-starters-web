import { motion } from 'framer-motion';
import { ContactForm } from './ContactForm';

export const Contact = () => {
  return (
    <section id="contact" className="py-20 bg-theme-dark text-theme-light">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl mx-auto text-center"
        >
          <h2 className="text-4xl font-bold mb-8 text-theme-accent">Let's Work Together</h2>
          <p className="text-theme-light/80 mb-12">
            Have a project in mind? Let's create something amazing together.
          </p>
          <ContactForm />
        </motion.div>
      </div>
    </section>
  );
};