import { motion } from 'framer-motion';

const tools = [
  {
    category: "Development",
    items: [
      "VS Code",
      "WebStorm",
      "Git",
      "Docker",
      "Postman",
      "Chrome DevTools"
    ]
  },
  {
    category: "Design",
    items: [
      "Figma",
      "Adobe XD",
      "Sketch",
      "Photoshop",
      "Illustrator"
    ]
  },
  {
    category: "Project Management",
    items: [
      "Jira",
      "Trello",
      "Asana",
      "GitHub Projects",
      "Notion"
    ]
  },
  {
    category: "Communication",
    items: [
      "Slack",
      "Discord",
      "Zoom",
      "Microsoft Teams",
      "Google Meet"
    ]
  }
];

export const Tools = () => {
  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <h2 className="text-4xl font-bold text-center text-white mb-16">Tools & Software</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {tools.map((category, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-gray-700 rounded-xl p-6"
              >
                <h3 className="text-xl font-bold text-white mb-4">{category.category}</h3>
                <div className="flex flex-wrap gap-2">
                  {category.items.map((tool, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 bg-gray-600 text-gray-300 rounded-full text-sm"
                    >
                      {tool}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};