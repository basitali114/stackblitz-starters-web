import { motion } from 'framer-motion';

const education = [
  {
    degree: "Master of Computer Science",
    school: "Stanford University",
    period: "2014 - 2016",
    description: "Specialized in Artificial Intelligence and Machine Learning. Graduated with honors.",
    achievements: [
      "Published research paper on Deep Learning",
      "Teaching Assistant for Advanced Algorithms",
      "Led student research group"
    ]
  },
  {
    degree: "Bachelor of Engineering",
    school: "MIT",
    period: "2010 - 2014",
    description: "Major in Computer Science and Engineering. Minor in Mathematics.",
    achievements: [
      "Dean's List all semesters",
      "President of Computing Society",
      "Internship at Google"
    ]
  }
];

export const Education = () => {
  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <h2 className="text-4xl font-bold text-center text-white mb-16">Education</h2>
          
          <div className="space-y-12">
            {education.map((edu, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="bg-gray-800 rounded-xl p-8"
              >
                <h3 className="text-2xl font-bold text-white mb-2">{edu.degree}</h3>
                <h4 className="text-xl text-blue-400 mb-2">{edu.school}</h4>
                <p className="text-gray-400 mb-4">{edu.period}</p>
                <p className="text-gray-300 mb-6">{edu.description}</p>
                <ul className="space-y-2">
                  {edu.achievements.map((achievement, i) => (
                    <li key={i} className="flex items-center text-gray-400">
                      <span className="w-2 h-2 bg-blue-500 rounded-full mr-3" />
                      {achievement}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};