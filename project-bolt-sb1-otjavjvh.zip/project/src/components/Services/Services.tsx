import { motion } from 'framer-motion';
import { IconCode, IconMobile, IconCloud, IconBrain } from './Icons';

const services = [
  {
    icon: <IconCode />,
    title: "Web Development",
    description: "Building responsive and performant web applications using modern frameworks and best practices.",
    features: [
      "Custom Web Applications",
      "E-commerce Solutions",
      "Progressive Web Apps",
      "API Development",
      "Performance Optimization",
      "SEO Implementation"
    ]
  },
  {
    icon: <IconMobile />,
    title: "Mobile Development",
    description: "Creating native and cross-platform mobile applications for iOS and Android platforms.",
    features: [
      "iOS Development",
      "Android Development",
      "Cross-platform Apps",
      "App Store Optimization",
      "Mobile UI/UX Design",
      "App Maintenance"
    ]
  },
  {
    icon: <IconCloud />,
    title: "Cloud Solutions",
    description: "Implementing scalable cloud infrastructure and DevOps practices for optimal performance.",
    features: [
      "Cloud Architecture",
      "AWS/Azure/GCP",
      "Serverless Computing",
      "CI/CD Implementation",
      "Container Orchestration",
      "Cloud Security"
    ]
  },
  {
    icon: <IconBrain />,
    title: "AI & Machine Learning",
    description: "Developing intelligent solutions using cutting-edge AI and machine learning technologies.",
    features: [
      "Data Analysis",
      "Predictive Models",
      "Natural Language Processing",
      "Computer Vision",
      "Recommendation Systems",
      "AI Integration"
    ]
  }
];

export const Services = () => {
  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-6xl mx-auto"
        >
          <h2 className="text-4xl font-bold text-center text-white mb-16">Services</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-gray-800 rounded-xl p-8 hover:transform hover:scale-105 transition-transform duration-300"
              >
                <div className="text-blue-500 w-16 h-16 mb-6">
                  {service.icon}
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">{service.title}</h3>
                <p className="text-gray-300 mb-6">{service.description}</p>
                <ul className="space-y-3">
                  {service.features.map((feature, i) => (
                    <li key={i} className="flex items-center text-gray-400">
                      <span className="w-2 h-2 bg-blue-500 rounded-full mr-3" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};