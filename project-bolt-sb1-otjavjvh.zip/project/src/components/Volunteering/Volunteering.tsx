import { motion } from 'framer-motion';

const volunteerWork = [
  {
    organization: "Code for Good",
    role: "Technical Mentor",
    period: "2022 - Present",
    description: "Mentoring aspiring developers and contributing to social impact projects.",
    achievements: [
      "Mentored 20+ junior developers",
      "Led 5 social impact projects",
      "Organized coding workshops"
    ]
  },
  {
    organization: "Tech Education Initiative",
    role: "Workshop Instructor",
    period: "2021 - Present",
    description: "Teaching coding skills to underprivileged students.",
    achievements: [
      "Conducted 15+ workshops",
      "Developed curriculum",
      "Reached 200+ students"
    ]
  },
  {
    organization: "Open Source Community",
    role: "Core Contributor",
    period: "2020 - Present",
    description: "Contributing to open source projects and organizing community events.",
    achievements: [
      "100+ pull requests merged",
      "Organized 10 hackathons",
      "Built developer community"
    ]
  }
];

export const Volunteering = () => {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <h2 className="text-4xl font-bold text-center mb-16">Volunteer Work</h2>
          
          <div className="space-y-8">
            {volunteerWork.map((work, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-gray-50 rounded-xl p-8"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-2xl font-bold mb-2">{work.organization}</h3>
                    <p className="text-blue-500 font-semibold">{work.role}</p>
                  </div>
                  <span className="text-gray-600">{work.period}</span>
                </div>
                <p className="text-gray-600 mb-4">{work.description}</p>
                <ul className="space-y-2">
                  {work.achievements.map((achievement, i) => (
                    <li key={i} className="flex items-center text-gray-600">
                      <span className="w-2 h-2 bg-blue-500 rounded-full mr-3" />
                      {achievement}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};