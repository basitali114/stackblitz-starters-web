import { useEffect, useRef } from 'react';

interface Star {
  x: number;
  y: number;
  length: number;
  speed: number;
  size: number;
}

export const ShootingStars = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const stars: Star[] = [];
    const FPS = 60;
    const STAR_COUNT = 20;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const createStar = (): Star => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      length: Math.random() * 80 + 10,
      speed: Math.random() * 10 + 5,
      size: Math.random() * 2 + 0.1
    });

    const initStars = () => {
      for (let i = 0; i < STAR_COUNT; i++) {
        stars.push(createStar());
      }
    };

    const drawStar = (star: Star) => {
      ctx.beginPath();
      ctx.lineCap = 'round';
      ctx.lineWidth = star.size;
      ctx.strokeStyle = 'rgba(102, 252, 241, 0.8)'; // theme-accent
      
      ctx.moveTo(star.x, star.y);
      ctx.lineTo(star.x + star.length, star.y);
      ctx.stroke();
    };

    const updateStar = (star: Star) => {
      star.x += star.speed;
      
      if (star.x > canvas.width) {
        star.x = -star.length;
        star.y = Math.random() * canvas.height;
      }
    };

    const animate = () => {
      ctx.fillStyle = 'rgba(11, 12, 16, 0.2)'; // theme-dark
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      stars.forEach(star => {
        drawStar(star);
        updateStar(star);
      });
      
      requestAnimationFrame(animate);
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    initStars();
    animate();

    return () => window.removeEventListener('resize', resizeCanvas);
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed top-0 left-0 w-full h-full -z-10"
      style={{ background: 'linear-gradient(to bottom, #0B0C10, #1F2833)' }}
    />
  );
};