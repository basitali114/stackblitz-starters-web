import { motion } from 'framer-motion';

const experiences = [
  {
    title: "Senior Software Engineer",
    company: "Tech Innovators Inc.",
    period: "2020 - Present",
    location: "San Francisco, CA",
    description: [
      "Led development of cloud-native applications using microservices architecture",
      "Mentored junior developers and conducted code reviews",
      "Implemented CI/CD pipelines reducing deployment time by 60%",
      "Architected scalable solutions handling millions of daily users"
    ]
  },
  {
    title: "Full Stack Developer",
    company: "Digital Solutions Ltd.",
    period: "2018 - 2020",
    location: "New York, NY",
    description: [
      "Developed responsive web applications using React and Node.js",
      "Optimized database queries improving performance by 40%",
      "Integrated third-party APIs and payment gateways",
      "Implemented real-time features using WebSocket"
    ]
  },
  {
    title: "Frontend Developer",
    company: "Creative Web Agency",
    period: "2016 - 2018",
    location: "Boston, MA",
    description: [
      "Built interactive user interfaces using modern JavaScript frameworks",
      "Collaborated with designers to implement pixel-perfect designs",
      "Improved website performance and SEO metrics",
      "Developed reusable component libraries"
    ]
  }
];

export const Experience = () => {
  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto"
        >
          <h2 className="text-4xl font-bold text-center text-white mb-16">Professional Experience</h2>
          
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-0 md:left-1/2 transform md:-translate-x-px top-0 h-full w-0.5 bg-blue-500" />
            
            {/* Experience items */}
            {experiences.map((exp, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className={`relative flex md:justify-between items-start mb-12 ${
                  index % 2 === 0 ? 'md:flex-row-reverse' : ''
                }`}
              >
                {/* Timeline dot */}
                <div className="absolute left-0 md:left-1/2 transform -translate-x-1/2 w-4 h-4 bg-blue-500 rounded-full" />
                
                {/* Content */}
                <div className={`ml-8 md:ml-0 md:w-5/12 ${
                  index % 2 === 0 ? 'md:text-right' : ''
                }`}>
                  <div className="bg-gray-700 rounded-lg p-6">
                    <h3 className="text-xl font-bold text-white mb-2">{exp.title}</h3>
                    <h4 className="text-blue-400 font-semibold mb-1">{exp.company}</h4>
                    <div className="text-gray-400 mb-4">
                      <span>{exp.period}</span>
                      <span className="mx-2">•</span>
                      <span>{exp.location}</span>
                    </div>
                    <ul className={`text-gray-300 space-y-2 ${
                      index % 2 === 0 ? 'md:ml-auto' : ''
                    }`}>
                      {exp.description.map((item, i) => (
                        <li key={i}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};